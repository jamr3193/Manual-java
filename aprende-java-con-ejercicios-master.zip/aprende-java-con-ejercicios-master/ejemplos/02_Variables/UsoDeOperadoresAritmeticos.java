/**
 * Uso de los operadores aritméticos
 *
 * @author Luis J. Sánchez
 */

public class UsoDeOperadoresAritmeticos {
  public static void main(String[] args) {
    int x;
    x = 100;

    System.out.println(x + " " + (x + 5) + " " + (x - 5));
    System.out.println((x * 5) + " " + (x / 5) + " " + (x % 5));
  }
}
