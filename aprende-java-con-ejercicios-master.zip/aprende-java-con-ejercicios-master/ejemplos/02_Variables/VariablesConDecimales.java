/**
 * Uso de variables que contienen números decimales
 *
 * @author Luis J. Sánchez
 */

public class VariablesConDecimales {
  public static void main(String[] args) {
    double x; // Se declaran las variables x e y
    double y; // de tal forma que puedan almacenar decimales.

    x = 7;
    y = 25.01;
    
    System.out.println(" x vale " + x);
    System.out.println(" y vale " + y);
  }
}
