/**
 * Uso de variables enteras
 *
 * @author Luis J. Sánchez
 */
 
public class VariablesEnteras {
  public static void main(String[] args) {
    int x; // Se declara la variable x como entera

    x = 5; // Se asigna el valor 5 a la variable x
    System.out.println("El valor actual de mi variable es " + x);

    x = 7; // Se asigna el valor 7 a la variable x
    System.out.println("y ahora es " + x);
  }
}
