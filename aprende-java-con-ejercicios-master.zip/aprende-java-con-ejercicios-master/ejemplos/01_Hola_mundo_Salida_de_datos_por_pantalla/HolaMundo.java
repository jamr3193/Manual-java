/**
 * Muestra por pantalla la frase "¡Hola mundo!"
 *
 * @author Luis J. Sánchez
 */

public class HolaMundo { // Clase principal
  public static void main(String[] args) {
    System.out.println("¡Hola mundo!");
  }
}
