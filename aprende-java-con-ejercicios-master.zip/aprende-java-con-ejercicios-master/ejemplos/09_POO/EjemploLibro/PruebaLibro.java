/**
 * PruebaLibro.java
 * Programa que prueba la clase Libro
 * @author Luis José Sánchez
 */

public class PruebaLibro {
  public static void main(String[] args) {
    
    Libro lib = new Libro();
    Libro miLibrito = new Libro();
    Libro quijote = new Libro();  
  }
}
