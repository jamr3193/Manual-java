/**
 * 
 * 1. Salida por pantalla
 *
 * 3. Escribe un programa que muestre por pantalla 10 palabras en inglés
 *    junto a su correspondiente traducción al castellano. Las palabras
 *    deben estar distribuidas en dos columnas y alineadas a la izquierda.
 *    Pista: Se puede insertar un tabulador mediante \t.
 *
 * @author Luis José Sánchez
 */

public class S01Ejercicio03 {
  public static void main(String[] args) {
    System.out.println("computer\tordenador\n");
    System.out.println("student\talumno\\a");
    System.out.println("cat\tgato");
    System.out.println("penguin\tpingüino");
    System.out.println("machine\tmáquina");
    System.out.println("nature\tnaturaleza");
    System.out.println("light\tluz");
    System.out.println("green\tverde");
    System.out.println("book\tlibro");
    System.out.println("pyramid\tpirámide");
  }
}
