/**
 *
 * 1. Salida por pantalla
 *
 * 2. Modifica el programa anterior para que además se muestre tu
 *    dirección y tu número de teléfono. Asegúrate de que los
 *    datos se muestran en líneas separadas.
 *
 * @author Luis José Sánchez
 */

public class S01Ejercicio02 {
  public static void main(String[] args) {
    System.out.println("Luis José Sánchez González");
    System.out.println("Larios, 180 - Málaga");
    System.out.println("Tel: 555 12 34 56");
  }
}
