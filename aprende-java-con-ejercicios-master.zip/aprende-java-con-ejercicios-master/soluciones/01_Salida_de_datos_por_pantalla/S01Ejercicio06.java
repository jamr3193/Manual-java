/**
 * 
 * 1. Salida por pantalla
 *
 * 6. Escribe un programa que pinte por pantalla una pirámide rellena a
 *    base de asteriscos. La base de la pirámide debe estar formada por
 *    9 asteriscos.
 *
 * @author Luis José Sánchez
 * 
 */

public class S01Ejercicio06 {
  public static void main(String[] args) {

    System.out.println("    *");    
    System.out.println("   ***");
    System.out.println("  *****");
    System.out.println(" *******");
    System.out.println("*********");
  }
}
