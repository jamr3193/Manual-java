public enum Sexo {
  MACHO, HEMBRA
}
