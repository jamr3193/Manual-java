/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo05/ErrorNoAsignada.java           *
 *********************************************/

class ErrorNoAsignada {
        public static void main (String[] args) {
                int v1, v2 = 2, v3;
                v1 = 1;

                System.out.println("v1 = " + v1);
                System.out.println("v2 = " + v2);
                System.out.println("v3 = " + v3);
        }
}

/******** Fin de ErrorNoAsignada.java *********/

