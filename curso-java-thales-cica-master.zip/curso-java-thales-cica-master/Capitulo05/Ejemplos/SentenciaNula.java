/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo05/SentenciaNula.java             *
 *********************************************/

class SentenciaNula {
        public static void main (String[] args) {
                ;
        }
}

/******** Fin de SentenciaNula.java ***********/

