/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo04/ErrorDeclaracion.java          *
 *********************************************/

class ErrorDeclaracion {
	public static void main (String[] args) {
		int declarada = 0;

		NO_declarada = declarada;
	}
}

/******** Fin de ErrorDeclaracion.java ********/

