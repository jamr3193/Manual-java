/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo04/ErrorIdentificador.java        *
 *********************************************/

class ErrorIdentificador {
	public static void main (String[] args) {
		int v = 0;
		int _ = 0;
		int $ = 0;
		int v1550 = 0;
		int v_ab3 = 0;
		int v$a = 0;
		int 1ab = 0;
		int \u0370 = 0;
	}
}

/******** Fin de ErrorIdentificador.java ********/

