/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo04/ErroresRealOU.java             *
 *********************************************/

class ErroresRealOU {
  public static void main (String[] args) {
    float overflow1 = 1e100000;
    float overflow2 = -1e100000;
    float underflow1 = 1e-100000;
    float underflow2 = -1e-100000;
  }
}

/******** Fin de ErroresRealOU.java ********/

