/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo03/LitBoolean.java                *
 *********************************************/

class LitBoolean {
	public static void main (String[] args) {
		boolean p;
		p = false;
		System.out.println("p = " + p);
	}
}

/******** Fin de LitBoolean.java *************/

