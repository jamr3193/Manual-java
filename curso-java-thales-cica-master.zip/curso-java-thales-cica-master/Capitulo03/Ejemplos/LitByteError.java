/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo03/LitByteError.java              *
 *********************************************/

class LitByteError {
	public static void main (String[] args) {
		byte curso = 351;
	}
}

/******** Fin de LitByteError.java ***********/

