
/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo03/LitEnterosReales.java          *
 *********************************************/

class LitEnterosReales {
	public static void main (String[] args) {
		int    entero = 5821;
		double doble  = 5821d;

		int    r_entero = entero / 10;
		double r_doble  = doble / 10;

		System.out.println("r_entero " + r_entero);
		System.out.println("r_doble  " + r_doble);
	}
}

/******** Fin de LitEnterosReales.java *******/

