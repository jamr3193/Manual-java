/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo03/LitByteRaro.java               *
 *********************************************/

class LitByteRaro {
        public static void main (String[] args) {
                byte var = 100;
                var = (byte) (var + var);
                System.out.println("var = " + var);
        }
}

/******** Fin de LitByteRaro.java ************/

