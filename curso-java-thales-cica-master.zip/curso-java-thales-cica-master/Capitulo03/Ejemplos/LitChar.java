/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo03/LitChar.java                   *
 *********************************************/

class LitChar {
	public static void main (String[] args) {
		char a1 = 'A';
		char a2 = '\101';
		char a3 = '\u0041';
		System.out.print("a1 = " + a1);
		System.out.print('\n');
		System.out.print("a2 = " + a2);
		System.out.print('\n');
		System.out.print("a3 = " + a3);
		System.out.print('\n');
	}
}

/******** Fin de LitChar.java ****************/

