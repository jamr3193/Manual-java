/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo03/Unicode1.java                  *
 *********************************************/

class Unicode1 {
	public static void main (String[] args) {
		System.out.println("\u005A");
		System.out.println("\u03A0 = 3.14159");
	}
}

/******** Fin de Unicode1.java ****************/

