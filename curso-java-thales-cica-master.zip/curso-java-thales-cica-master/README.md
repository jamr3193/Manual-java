# Ejercicios del curso de Java de Thales CICA

Ejercicios del curso de Java de Thales CICA **Programación Orientada a Objetos y Funcional con Java 8**.
