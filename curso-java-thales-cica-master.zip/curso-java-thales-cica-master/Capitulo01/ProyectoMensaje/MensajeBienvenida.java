
/**
 * Mi primer programa con BlueJ. Esto tiene buena pinta jeje.
 * 
 * @author Luis José Sánchez
 * @version 18 de febrero de 2016
 */
public class MensajeBienvenida
{
  /**
   * Método main
   */
  public static void main(String[] args) {
    System.out.println("Mensaje de bienvenida...");
    System.out.println("...y algo más para comprobar que no se generan errores.");
  }
}
