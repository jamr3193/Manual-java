/*********************************************
* Jose F. Quesada                           *
*                Curso de Programación Java *
* Capitulo01/mensaje.java                   *
*********************************************/
class Mensaje {
  public static void main (String[] args) {
    System.out.println("Empezamos bien");
  }
}
/******** Fin de mensaje.java ****************/
