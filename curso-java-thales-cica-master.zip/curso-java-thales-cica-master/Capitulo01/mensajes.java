/*********************************************
 * Jose F. Quesada                           *
 *                Curso de Programación Java *
 * Capitulo01/mensajes.java                  *
 *********************************************/
class MensajeBienvenida {
  public static void main (String[] args) {
    System.out.println("Hola");
  }
}
class MensajeDespedida {
  public static void main (String[] args) {
    System.out.println("Adiós");
  }
}
/******** Fin de mensajes.java ***************/
