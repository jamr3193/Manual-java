
/**
 * Programa que escribe mi nombre
 * 
 * @author Luis José Sánchez
 * @version 27 de febrero de 2016
 */
public class MiNombre
{
  public static void main(String[] args) {
    System.out.println("Luis José Sánchez González");
  }
}
